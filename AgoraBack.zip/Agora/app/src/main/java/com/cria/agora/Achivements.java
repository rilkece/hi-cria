package com.cria.agora;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Achivements extends AppCompatActivity {

    private ImageButton imgBtnvoltarfromAchieve;

    private ImageView imgEco;
    private ImageView imgForest;
    private ImageView imgHalloween;
    private ImageView imgLabor;
    private ImageView imgNumber;
    private ImageView imgSaturn;
    private ImageView imgThanksgiving;
    private ImageView imgTravel;
    private ImageView imgSummer;
    private ImageView imgUnicorn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_achivements);

        //declarar elementos
        imgEco = findViewById(R.id.imgBadgeEco);
        imgForest = findViewById(R.id.imgBadgeForest);
        imgHalloween = findViewById(R.id.imgBadgeHalloween);
        imgLabor = findViewById(R.id.imgBadgeLabor);
        imgNumber = findViewById(R.id.imgBadgeNumber);
        imgSaturn = findViewById(R.id.imgBadgeSaturn);
        imgSummer = findViewById(R.id.imgBadgeSummer);
        imgThanksgiving = findViewById(R.id.imgBadgeThanksgiving);
        imgTravel = findViewById(R.id.imgBadgeTravel);
        imgUnicorn = findViewById(R.id.imgBadgeUnicorn);

        imgBtnvoltarfromAchieve = findViewById(R.id.imgbtnAchieveBack);

        //ações
        imgBtnvoltarfromAchieve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iAvatarMain = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(iAvatarMain);
            }
        });

        //funções
        setarBadges(Login.usuario.getTipoUser());
    }

    private void setarBadges(long tipoUser) {
        if(tipoUser==0){
            imgEco.setImageResource(R.drawable.badge_ecofriendly);
            imgForest.setImageResource(R.drawable.badge_forest);
            imgHalloween.setImageResource(R.drawable.badge_halloween);
            imgLabor.setImageResource(R.drawable.badge_laborday);
            imgNumber.setImageResource(R.drawable.badge_numberone);
            imgSaturn.setImageResource(R.drawable.badge_saturn);
            imgSummer.setImageResource(R.drawable.badge_summertime);
            imgThanksgiving.setImageResource(R.drawable.badge_thanksgiving);
            imgTravel.setImageResource(R.drawable.badge_travel);
            imgUnicorn.setImageResource(R.drawable.badge_unicorn);
        }else {
            if (Login.userAchievementes.getBadgeEco()){
                imgEco.setImageResource(R.drawable.badge_ecofriendly);
            }
            if (Login.userAchievementes.getBadgeForest()){
                imgForest.setImageResource(R.drawable.badge_forest);
            }
            if (Login.userAchievementes.getBadgeHalloween()){
                imgHalloween.setImageResource(R.drawable.badge_halloween);
            }
            if (Login.userAchievementes.getBadgeLaborDay()){
                imgLabor.setImageResource(R.drawable.badge_laborday);
            }
            if (Login.userAchievementes.getBadgeNumberOne()){
                imgNumber.setImageResource(R.drawable.badge_numberone);
            }
            if (Login.userAchievementes.getBadgeSaturn()){
                imgSaturn.setImageResource(R.drawable.badge_saturn);
            }
            if (Login.userAchievementes.getBadgeSummer()){
                imgSummer.setImageResource(R.drawable.badge_summertime);
            }
            if (Login.userAchievementes.getBadgeThanksgiving()){
                imgThanksgiving.setImageResource(R.drawable.badge_thanksgiving);
            }
            if (Login.userAchievementes.getBadgeTravel()){
                imgTravel.setImageResource(R.drawable.badge_travel);
            }
            if (Login.userAchievementes.getBadgeUnicorn()){
                imgUnicorn.setImageResource(R.drawable.badge_unicorn);
            }

        }

    }
}
