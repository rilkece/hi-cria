package com.cria.agora;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.LocaleList;
import android.speech.RecognizerIntent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.akexorcist.roundcornerprogressbar.IconRoundCornerProgressBar;
import com.akexorcist.roundcornerprogressbar.RoundCornerProgressBar;
import com.bumptech.glide.Glide;
import com.gitonway.lee.niftymodaldialogeffects.lib.Effectstype;
import com.gitonway.lee.niftymodaldialogeffects.lib.NiftyDialogBuilder;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.sccomponents.playerbutton.ScPlayerButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;

import Classes.PageActivities;
import Classes.SoundPlayer;
import TiposdeAtividades.PerguntaAlterna;

public class PaginaDeAtividades extends AppCompatActivity {

    private static final int REQUEST_CODE_SPEECH_INPUT = 1000;
    public static String codPageDay;
    private int pontuaçãoAcumulada = 0;
    private Button btnVoltar;
    private Button btnEditAtv;
    private TextView pontuação;
    private FirebaseDatabase fireDataAtividades;
    private DatabaseReference dataAtividade;
    private DatabaseReference dataPageActivity;
    private DatabaseReference parametersReference;
    private String dia;
    private String pagina = "page";

    private ImageButton floatNextpage;

    private TextView pergunta;

    private int codpageAtual = 0;

    private PageActivities pageActivities;
    private RoundCornerProgressBar progressBar;
    private PerguntaAlterna perguntaAlterna;

    private Button btnAlt1;
    private Button btnAlt2;
    private Button btnAlt3;
    private Button btnAlt4;

    private ImageView imagePages;
    private FloatingActionButton playAudio;
    private VideoView videoView;
    private WebView webPDFView;
    private ProgressBar progressPDFBar;

    private SoundPlayer soundPlayer;
    private FloatingActionButton fabMicAtv6;

    private TextView textAnswer;
    private TextView txtLoading;
    private IconRoundCornerProgressBar iconRoundCornerProgressBarAtv7;
    private int iTimesListened = 0;

    private int iPlay = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pagina_de_atividades_activity);
        //iniciar elementos de layout
        progressBar = findViewById(R.id.progressBarPages);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnEditAtv = findViewById(R.id.btnEditAtv);
        pontuação = findViewById(R.id.txtScorePage);
        pontuação.setText(String.valueOf(pontuaçãoAcumulada));
        floatNextpage = findViewById(R.id.imgBtnNextPage);
        soundPlayer = new SoundPlayer(this);

        floatNextpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextPage();
            }
        });
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iVolta = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(iVolta);
                finish();
            }
        });

        if (Login.usuario.getTipoUser()==0){
            btnEditAtv.setVisibility(View.VISIBLE);
        }

        if (savedInstanceState == null) {
            //iniciar firebasedatabase
            fireDataAtividades = FirebaseDatabase.getInstance();


            //setar pageActivities com dados da activity do dia
            dataPageActivity = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("numPages");
            dataPageActivity.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    pageActivities = new PageActivities(Integer.valueOf(dataSnapshot.getValue().toString()), codPageDay, Week.codAtividade);
                    progressBar.setMax(pageActivities.getNumPage());

                   // Toast.makeText(getApplicationContext(), codPageDay, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            construirPaginas();

        }


    }

    private void nextPage() {
        if (pageActivities.getNumPage()>codpageAtual){
            construirPaginas();
            floatNextpage.setVisibility(View.INVISIBLE);
            soundPlayer.playDingSound();
        }else {
            final Intent iMain = new Intent(getApplicationContext(), MainActivity.class);
            FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("score").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.getValue()!=null){
                        final long scoreCRIA = Long.valueOf(dataSnapshot.getValue().toString())+pontuaçãoAcumulada;
                        DatabaseReference dataScoreCRIA = FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("score");
                        dataScoreCRIA.setValue(scoreCRIA);
                    }else {
                        DatabaseReference dataScoreCRIA = FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("score");
                        dataScoreCRIA.setValue(pontuaçãoAcumulada);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


            final DatabaseReference datanewScore = fireDataAtividades.getReference("users").child(Login.usuario.getMatricula()).child("desempenho").child("score");
            datanewScore.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    datanewScore.setValue(Integer.valueOf(dataSnapshot.getValue().toString())+pontuaçãoAcumulada);
                    startActivity(iMain);
                    finish();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    datanewScore.setValue(pontuaçãoAcumulada);
                    startActivity(iMain);
                    finish();

                }
            });
            final DatabaseReference dataweekScore = fireDataAtividades.getReference("users").child(Login.usuario.getMatricula()).child("desempenho").child("weekScore").child(Week.codAtividade);
            dataweekScore.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getValue()==null){
                        dataweekScore.setValue(pontuaçãoAcumulada);
                    }else {
                        dataweekScore.setValue(Integer.valueOf(dataSnapshot.getValue().toString()) + pontuaçãoAcumulada);
                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            final DatabaseReference dataDayScore = fireDataAtividades.getReference("users").child(Login.usuario.getMatricula()).child("desempenho").child("dayScore").child(codPageDay);
            dataDayScore.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getValue()==null){
                        dataDayScore.setValue(pontuaçãoAcumulada);
                    }else {
                        dataDayScore.setValue(Integer.valueOf(dataSnapshot.getValue().toString()) + pontuaçãoAcumulada);
                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            soundPlayer.playCompletedSound();
        }
    }

    private void construirPaginas() {
        //Buscar o tipo de atividade e setar o fragment de acordo com ela
        codpageAtual = codpageAtual+1;
        progressBar.setProgress(codpageAtual);

        dataAtividade = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("tipoAtv");
        dataAtividade.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                final String iTipoAtv = String.valueOf(dataSnapshot.getValue());
                btnEditAtv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                    SetActivity.ipaginaAtividade=codpageAtual;
                    EscolhaTipoAtividade.COD_EDIT_ATV=1;
                    Intent iEdit = new Intent(getApplicationContext(), EscolhaTipoAtividade.class);
                    startActivity(iEdit);
                    finish();
                    }
                });


                switch (iTipoAtv){
                    case "1":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv1())
                                .commitNow();

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela
                        parametersFragmentPoints();
                        //setar pergunta, esse parâmetro tem todas as telas
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //setar parâmetros específicos
                        parametersPerguntaAlterna(1);
                        //verificar se atividae já foi realizada
                        verificaAtividade();

                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getCodPag(), Toast.LENGTH_SHORT).show();

                        break;
                    case "2":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv2())
                                .commitNow();

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //setar pergunta - igual pra todos que tem perguta ou instrução.
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(2);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo "+e, Toast.LENGTH_SHORT).show();
                            e.printStackTrace();
                        }
                        //setar parâmetros específicos - igual pra todos que tem alternativa
                        parametersPerguntaAlterna(2);
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();

                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getCodPag(), Toast.LENGTH_SHORT).show();

                        break;
                    case "3":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv3())
                                .commitNow();
                        txtLoading= findViewById(R.id.txtLoadingAtv3);

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //setar pergunta - igual pra todos que tem perguta ou instrução.
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(3);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo, pois  "+e, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        //setar parâmetros específicos - igual pra todos que tem alternativa
                        parametersPerguntaAlterna(3);
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();

                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getCodPag(), Toast.LENGTH_SHORT).show();

                        break;
                    case "4":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv4())
                                .commitNow();

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //setar pergunta - igual pra todos que tem perguta ou instrução.
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(4);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo, pois  "+e, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        //setar parâmetros específicos - igual pra todos que tem alternativa
                        parametersPerguntaAlterna(4);
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();

                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getCodPag(), Toast.LENGTH_SHORT).show();

                        break;
                    case "5":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv5())
                                .commitNow();

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //setar pergunta - igual pra todos que tem perguta ou instrução.
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(5);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo, pois  "+e, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();
                        floatNextpage.setVisibility(View.VISIBLE);
                        break;
                    case "6":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv6())
                                .commitNow();

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //setar pergunta - igual pra todos que tem perguta ou instrução.
                        parametersPergunta(Integer.valueOf(iTipoAtv));
                        //setar parâmetros específicos - igual pra todos que tem alternativa
                        parametersVoiceAlterna(6);
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(6);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo, pois  "+e, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();
                        floatNextpage.setVisibility(View.VISIBLE);
                        break;
                    case "7":
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.container2, new fragAtv7())
                                .commitNow();

                        txtLoading= findViewById(R.id.txtLoadingAtv7);

                        perguntaAlterna = new PerguntaAlterna();
                        perguntaAlterna.setCodPag(codPageDay+codpageAtual);
                        iconRoundCornerProgressBarAtv7 = findViewById(R.id.progressAtv7);
                        //setar pontos da tela - igual pra todos
                        parametersFragmentPoints();
                        //carregar imagens - igual para todos que têm imagens
                        try {
                            loadMedia(7);
                        } catch (IOException e) {
                           //Toast.makeText(getApplicationContext(),"não deu certo, pois  "+e, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                        //verificar se atividae já foi realizada - igual pra todos
                        verificaAtividade();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "ops, sem tipo de atividade", Toast.LENGTH_LONG).show();
            }
        });
    }



    private void loadMedia(int iMages) throws IOException {
        StorageReference storageReference = FirebaseStorage.getInstance().getReference("imgPages").child(Week.codAtividade).child(Week.diaDaSemana).child(codPageDay+codpageAtual);
        switch (iMages){
            case 1:
                break;
            case 2:
                imagePages = findViewById(R.id.imgAtv2);
                Glide.with(getApplicationContext())
                        .load(storageReference)
                        .into(imagePages);
                break;
            case 3:
                playAudio = findViewById(R.id.playerAtv3);
                final MediaPlayer mediaPlayer = new MediaPlayer();
                playAudio.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        txtLoading.setVisibility(View.VISIBLE);
                        DatabaseReference dataAudio = FirebaseDatabase.getInstance().getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child("page"+codpageAtual).child("parameters").child("url");
                        dataAudio.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

                                    try {
                                        if (!mediaPlayer.isPlaying()) {
                                            final String url = String.valueOf(dataSnapshot.getValue()); // your URL here
                                            mediaPlayer.setDataSource(url);
                                            mediaPlayer.prepareAsync();
                                            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                                @Override
                                                public void onCompletion(MediaPlayer mp) {
                                                    playAudio.setImageResource(R.drawable.ic_play_arrow_black_24dp);
                                                    mediaPlayer.release();
                                                }
                                            });
                                            //Toast.makeText(getApplicationContext(), "setou url", Toast.LENGTH_LONG).show();

                                            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                                                @Override
                                                public void onPrepared(MediaPlayer mp) {
                                                    mp.setLooping(false);
                                                    mediaPlayer.start();
                                                    txtLoading.setVisibility(View.INVISIBLE);
                                                    playAudio.setImageResource(R.drawable.ic_stop_white_24dp);
                                                    //Toast.makeText(getApplicationContext(), String.valueOf(mediaPlayer.isPlaying()), Toast.LENGTH_LONG).show();
                                                    Toast.makeText(getApplicationContext(), "Loading audio, please wait...", Toast.LENGTH_LONG).show();
                                                }
                                            });
                                        }else {
                                            mediaPlayer.stop();
                                            mediaPlayer.reset();
                                            playAudio.setImageResource(R.drawable.ic_play_arrow_black_24dp);
                                        }
                                    }catch (IOException e) {
                                        e.printStackTrace();
                                        //Toast.makeText(getApplicationContext(), "deu erro", Toast.LENGTH_LONG).show();

                                    }

                                    //Toast.makeText(getApplicationContext(), "async", Toast.LENGTH_LONG).show();


                                mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                                    @Override
                                    public boolean onError(MediaPlayer mp, int what, int extra) {
                                        //Toast.makeText(getApplicationContext(),url, Toast.LENGTH_LONG).show();
                                        return false;
                                    }
                                });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "áudio não encontrado.", Toast.LENGTH_LONG).show();
                            }
                        });



                    }
                });


                break;
            case 4:
                videoView = findViewById(R.id.playerAtv4);
                final ImageButton imgPlayStop = findViewById(R.id.btnPlayStopAtv4);
                imgPlayStop.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final ProgressDialog mDialog = new ProgressDialog(PaginaDeAtividades.this);

                        DatabaseReference dataVideo = FirebaseDatabase.getInstance().getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child("page"+codpageAtual).child("parameters").child("url");
                        dataVideo.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                try {
                                    if (!videoView.isPlaying()){
                                        mDialog.setMessage("please wait");
                                        mDialog.setCanceledOnTouchOutside(false);
                                        mDialog.show();
                                        final String urlVideo = String.valueOf(dataSnapshot.getValue()); // your URL here
                                        Uri uriVideo = Uri.parse(urlVideo);
                                        videoView.setVideoURI(uriVideo);
                                        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                            @Override
                                            public void onCompletion(MediaPlayer mp) {
                                                imgPlayStop.setImageResource(R.drawable.ic_play_arrow_black_24dp);
                                            }
                                        });
                                    }else {
                                        videoView.pause();
                                        imgPlayStop.setImageResource(R.drawable.ic_play_arrow_black_24dp);
                                    }

                                }catch (Exception ex){

                                }
                                videoView.requestFocus();
                                videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                                    @Override
                                    public void onPrepared(MediaPlayer mp) {
                                        mDialog.dismiss();
                                        mp.setLooping(false);
                                        ViewGroup.LayoutParams params = videoView.getLayoutParams();
                                        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                                        videoView.setLayoutParams(params);
                                        videoView.start();
                                        imgPlayStop.setImageResource(R.drawable.ic_stop_white_24dp);

                                    }
                                });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });

                break;
            case 5:
                webPDFView = findViewById(R.id.webPDFview);
                progressPDFBar = findViewById(R.id.progressPDFbar);
                webPDFView.getSettings().setJavaScriptEnabled(true);
                DatabaseReference dataPDF = FirebaseDatabase.getInstance().getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child("page"+codpageAtual).child("parameters").child("url");
                dataPDF.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        final String urlPDF = String.valueOf(dataSnapshot.getValue()); // your URL here
                        webPDFView.loadUrl(urlPDF);
                        webPDFView.setWebViewClient(new WebViewClient(){
                            public void  onPageFinished(WebView web, String url){
                                progressPDFBar.setVisibility(View.GONE);
                            }
                        });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                break;
            case 6:
                fabMicAtv6 = findViewById(R.id.fabAtv6);
                final TextView textMain = findViewById(R.id.txtMainAtv6);
                DatabaseReference datatextMain = FirebaseDatabase.getInstance().getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child("page"+codpageAtual).child("parameters").child("correctAlt");
                datatextMain.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        textMain.setText(String.valueOf(dataSnapshot.getValue()));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                textAnswer = findViewById(R.id.txtAnswerAtv6);
                fabMicAtv6.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        speak();
                    }
                });

                break;
            case 7:

                playAudio = findViewById(R.id.playerAtv7);
                playAudio.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        txtLoading.setVisibility(View.VISIBLE);
                        playAudio.hide();
                        if (iPlay == 0) {
                        DatabaseReference dataAudio = FirebaseDatabase.getInstance().getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child("page" + codpageAtual).child("parameters").child("url");
                        dataAudio.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                final String url = String.valueOf(dataSnapshot.getValue()); // your URL here
                                final MediaPlayer mediaPlayer = new MediaPlayer();
                                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                                try {
                                    mediaPlayer.setDataSource(url);
                                } catch (IOException e) {
                                    e.printStackTrace();

                                }
                                mediaPlayer.setLooping(false);
                                mediaPlayer.prepareAsync();


                                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                                    @Override
                                    public void onPrepared(MediaPlayer mp) {
                                        playAudio.setImageDrawable(getResources().getDrawable(R.drawable.ic_sound));
                                        iPlay = 1;
                                        mediaPlayer.start();
                                        playAudio.show();
                                        txtLoading.setVisibility(View.INVISIBLE);
                                        //Toast.makeText(getApplicationContext(), String.valueOf(mediaPlayer.getDuration()), Toast.LENGTH_LONG).show();

                                    }
                                });
                                mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                                    @Override
                                    public boolean onError(MediaPlayer mp, int what, int extra) {
                                       //Toast.makeText(getApplicationContext(), url, Toast.LENGTH_LONG).show();
                                        return false;
                                    }
                                });
                                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                                    @Override
                                    public void onCompletion(MediaPlayer mp) {
                                        playAudio.show();playAudio.hide();
                                        playAudio.setImageDrawable(getResources().getDrawable(R.drawable.ic_play_arrow_white_24dp));
                                        playAudio.show();
                                       // Toast.makeText(getApplicationContext(), "mudou pra seta", Toast.LENGTH_LONG).show();
                                        iPlay =0;
                                        if (iTimesListened == 3) {

                                        } else if (iTimesListened == 2) {
                                            iconRoundCornerProgressBarAtv7.setProgress(3);
                                            iconRoundCornerProgressBarAtv7.setIconBackgroundColor(getResources().getColor(R.color.Icon3));
                                            iconRoundCornerProgressBarAtv7.setProgressColor(getResources().getColor(R.color.Progress3));
                                            iconRoundCornerProgressBarAtv7.setIconImageResource(R.drawable.ic_super);
                                            iTimesListened = 3;
                                            pontuaçãoAcumulada = pontuaçãoAcumulada + perguntaAlterna.getPontos();
                                            pontuação.setText(String.valueOf("+" + pontuaçãoAcumulada));
                                            floatNextpage.setVisibility(View.VISIBLE);
                                            mediaPlayer.release();
                                        } else if (iTimesListened == 1) {
                                            iconRoundCornerProgressBarAtv7.setProgress(2);
                                            iconRoundCornerProgressBarAtv7.setIconBackgroundColor(getResources().getColor(R.color.Icon2));
                                            iconRoundCornerProgressBarAtv7.setProgressColor(getResources().getColor(R.color.Progress2));
                                            iconRoundCornerProgressBarAtv7.setIconImageResource(R.drawable.ic_happy);
                                            iTimesListened = 2;
                                        } else if (iTimesListened == 0) {
                                            iconRoundCornerProgressBarAtv7.setProgress(1);
                                            iconRoundCornerProgressBarAtv7.setIconBackgroundColor(getResources().getColor(R.color.Icon1));
                                            iconRoundCornerProgressBarAtv7.setProgressColor(getResources().getColor(R.color.Progress1));
                                            iconRoundCornerProgressBarAtv7.setIconImageResource(R.drawable.ic_normal);
                                            iTimesListened = 1;
                                        }


                                    }
                                });

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(getApplicationContext(), "áudio não encontrado.", Toast.LENGTH_LONG).show();
                                playAudio.show();
                            }
                        });


                    }else {
                            Toast.makeText(getApplicationContext(), "Listen the audio.", Toast.LENGTH_SHORT).show();
                            playAudio.show();
                            txtLoading.setVisibility(View.INVISIBLE);
                        }
                }
                });
                break;

        }

    }

    private void speak() {
        //intent to show speech to text dialog
        Intent intentSpeak = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intentSpeak.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intentSpeak.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toString());
        intentSpeak.putExtra(RecognizerIntent.EXTRA_PROMPT, "Hi, speak, please!");

        //start intent
        try {
            //if there was no error
            //show dialog
            startActivityForResult(intentSpeak, REQUEST_CODE_SPEECH_INPUT);
        }catch (Exception ex){
            //if there was some error
            Toast.makeText(getApplicationContext(), ""+ex.getMessage(), Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case  REQUEST_CODE_SPEECH_INPUT:{
                if (resultCode == RESULT_OK && null!= data){
                    //get text array from voice intent
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    //set to text view
                    textAnswer.setText(result.get(0));
                    verificaVoice(String.valueOf(textAnswer.getText()));

                }
            }
        }
    }

    private void verificaVoice(String answer) {
        textAnswer.setVisibility(View.VISIBLE);
        if(answer.equals(perguntaAlterna.getAlt1()) || answer.equals(perguntaAlterna.getAlt2()) || answer.equals(perguntaAlterna.getAlt3()) || answer.equals(perguntaAlterna.getAlt4())){
            textAnswer.setBackgroundColor(getResources().getColor(R.color.verde_correto));
            pontuaçãoAcumulada = pontuaçãoAcumulada+perguntaAlterna.getPontos();
            pontuação.setText(String.valueOf("+"+pontuaçãoAcumulada));
            soundPlayer.playCorrectSound();
            fabMicAtv6.hide();

        } else {
            textAnswer.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
            soundPlayer.playWrongSound();
            //Toast.makeText(getApplicationContext(), String.valueOf(perguntaAlterna.getAlt3()), Toast.LENGTH_LONG).show();
        }

    }

    private void verificaAtividade() {
        final DatabaseReference dataVerificaAtv = fireDataAtividades.getReference("users").child(Login.usuario.getMatricula()).child("AtvRealizadas").child(perguntaAlterna.getCodPag());
        dataVerificaAtv.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (String.valueOf(dataSnapshot.getValue()).equals("sim")){

                } else{
                    FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("atvRealizadas").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.getValue()!=null){
                                final long atvCRIA = Long.valueOf(dataSnapshot.getValue().toString())+1;
                                DatabaseReference dataAtvCRIA = FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("atvRealizadas");
                                dataAtvCRIA.setValue(atvCRIA);
                                //Toast.makeText(getApplicationContext(), dataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                            }else {
                                DatabaseReference dataAtvCRIA = FirebaseDatabase.getInstance().getReference("schools").child(String.valueOf(Login.usuario.getUtbCRIA())).child("desempenho").child("atvRealizadas");
                                dataAtvCRIA.setValue(1);
                                //Toast.makeText(getApplicationContext(), dataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                    final DatabaseReference databaseReferenceAtv =  fireDataAtividades.getReference("users").child(Login.usuario.getMatricula()).child("desempenho").child("atvRealizadas");
                    databaseReferenceAtv.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            databaseReferenceAtv.setValue(Long.valueOf(dataSnapshot.getValue().toString())+1);
                            dataVerificaAtv.setValue("sim");
                            //Toast.makeText(getApplicationContext(), "dois", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            //Toast.makeText(getApplicationContext(), "tres", Toast.LENGTH_SHORT).show();
                        }
                    });

                }
                //Toast.makeText(getApplicationContext(), String.valueOf(dataSnapshot.getValue()), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void parametersVoiceAlterna(int iVoiceAlterna) {
        //setar correctAlt
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("correctAlt");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAltCerta(String.valueOf(dataSnapshot.getValue().toString()));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com correctAlt", Toast.LENGTH_SHORT).show();

            }
        });
        //setar Alt1
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt1");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt1(String.valueOf(dataSnapshot.getValue().toString()));
               //Toast.makeText(getApplicationContext(), "setant alt 1, alt1: "+perguntaAlterna.getAlt1(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt1", Toast.LENGTH_SHORT).show();

            }
        });
        //setar Alt2
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt2");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt2(String.valueOf(dataSnapshot.getValue().toString()));
                //Toast.makeText(getApplicationContext(), "setant alt 2, alt2: "+perguntaAlterna.getAlt2(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt2", Toast.LENGTH_SHORT).show();

            }
        });
        //setar Alt3
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt3");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt3(String.valueOf(dataSnapshot.getValue().toString()));
                //Toast.makeText(getApplicationContext(), "setant alt 3, alt3: "+perguntaAlterna.getAlt3(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt3", Toast.LENGTH_SHORT).show();

            }
        });
        //setar Alt4
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt4");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt4(String.valueOf(dataSnapshot.getValue().toString()));
                //Toast.makeText(getApplicationContext(), "setant alt 4, alt4: "+perguntaAlterna.getAlt4(), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt4", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void parametersPerguntaAlterna(int iAlterna) {
        //variável pra verificar se os botões já foram apertados
        final int[] apertouBotao = {0};

        //declara elementos
        switch (iAlterna){
            case 1:
                btnAlt1 = findViewById(R.id.btn1Atv1);
                btnAlt2 = findViewById(R.id.btn2Atv1);
                btnAlt3 = findViewById(R.id.btn3Atv1);
                btnAlt4 = findViewById(R.id.btn4Atv1);
                break;
            case 2:
                btnAlt1 = findViewById(R.id.btn1Atv2);
                btnAlt2 = findViewById(R.id.btn2Atv2);
                btnAlt3 = findViewById(R.id.btn3Atv2);
                btnAlt4 = findViewById(R.id.btn4Atv2);
                break;
            case 3:
                btnAlt1 = findViewById(R.id.btn1Atv3);
                btnAlt2 = findViewById(R.id.btn2Atv3);
                btnAlt3 = findViewById(R.id.btn3Atv3);
                btnAlt4 = findViewById(R.id.btn4Atv3);
                break;
            case 4:
                btnAlt1 = findViewById(R.id.btn1Atv4);
                btnAlt2 = findViewById(R.id.btn2Atv4);
                btnAlt3 = findViewById(R.id.btn3Atv4);
                btnAlt4 = findViewById(R.id.btn4Atv4);
                break;

        }


        //setar correctAlt
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("correctAlt");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAltCerta(String.valueOf(dataSnapshot.getValue().toString()));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com correctAlt", Toast.LENGTH_SHORT).show();

            }
        });
        //setar alt1
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt1");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt1(String.valueOf(dataSnapshot.getValue().toString()));
               btnAlt1.setText(perguntaAlterna.getAlt1());
                btnAlt1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (apertouBotao[0] ==0) {
                            apertouBotao[0] = 1;
                            verificaPerguntaAlterna(perguntaAlterna.getAltCerta(), 1);
                        }else {
                            Toast.makeText(getApplicationContext(), "Você já respondeu a essa questão.", Toast.LENGTH_SHORT).show();
                        }
                                            }
                });


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt1 ", Toast.LENGTH_SHORT).show();

            }
        });
        //setar alt2
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt2");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt2(String.valueOf(dataSnapshot.getValue().toString()));

                btnAlt2.setText(perguntaAlterna.getAlt2());
                btnAlt2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (apertouBotao[0] ==0) {
                            apertouBotao[0] = 1;
                            verificaPerguntaAlterna(perguntaAlterna.getAltCerta(), 2);
                        }else {
                            Toast.makeText(getApplicationContext(), "Você já respondeu a essa questão.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt2 ", Toast.LENGTH_SHORT).show();

            }
        });
        //setar alt3
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt3");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt3(String.valueOf(dataSnapshot.getValue().toString()));

                btnAlt3.setText(perguntaAlterna.getAlt3());
                btnAlt3.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (apertouBotao[0] ==0) {
                            apertouBotao[0] = 1;
                            verificaPerguntaAlterna(perguntaAlterna.getAltCerta(), 3);
                        }else {
                            Toast.makeText(getApplicationContext(), "Você já respondeu a essa questão.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt3 ", Toast.LENGTH_SHORT).show();

            }
        });
        //setar alt4
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("alt4");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setAlt4(String.valueOf(dataSnapshot.getValue().toString()));

                btnAlt4.setText(perguntaAlterna.getAlt4());
                btnAlt4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (apertouBotao[0] ==0) {
                            apertouBotao[0] = 1;
                            verificaPerguntaAlterna(perguntaAlterna.getAltCerta(), 4);
                        }else {
                            Toast.makeText(getApplicationContext(), "Você já respondeu a essa questão.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro com alt4 ", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void verificaPerguntaAlterna(String altCerta, int iResposta) {


        btnAlt1.setTextColor(getResources().getColor(R.color.branco));
        btnAlt2.setTextColor(getResources().getColor(R.color.branco));
        btnAlt3.setTextColor(getResources().getColor(R.color.branco));
        btnAlt4.setTextColor(getResources().getColor(R.color.branco));

        switch (altCerta){
            case "1":
                btnAlt1.setBackgroundColor(getResources().getColor(R.color.verde_correto));
                btnAlt2.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt3.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt4.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                break;
            case "2":
                btnAlt1.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt2.setBackgroundColor(getResources().getColor(R.color.verde_correto));
                btnAlt3.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt4.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                break;
            case "3":
                btnAlt1.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt2.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt3.setBackgroundColor(getResources().getColor(R.color.verde_correto));
                btnAlt4.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                break;
            case "4":
                btnAlt1.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt2.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt3.setBackgroundColor(getResources().getColor(R.color.vermelho_errado));
                btnAlt4.setBackgroundColor(getResources().getColor(R.color.verde_correto));
                break;
        }

        if (altCerta.equals(String.valueOf(iResposta))){
            pontuaçãoAcumulada = pontuaçãoAcumulada+perguntaAlterna.getPontos();
            pontuação.setText(String.valueOf("+"+pontuaçãoAcumulada));
            soundPlayer.playCorrectSound();
        }else {
            soundPlayer.playWrongSound();
        }
        floatNextpage.setVisibility(View.VISIBLE);
    }


    private void parametersPergunta(final int tipoAtv) {

        //setar pergunta
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("parameters").child("pergunta");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                switch (tipoAtv){
                    case 1:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        pergunta = findViewById(R.id.txtPerguntaAtv1);
                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getPergunta(), Toast.LENGTH_SHORT).show();
                        pergunta.setText(perguntaAlterna.getPergunta());

                        break;
                    case 2:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        pergunta = findViewById(R.id.txtPerguntaAtv2);
                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getPergunta(), Toast.LENGTH_SHORT).show();
                        pergunta.setText(perguntaAlterna.getPergunta());

                        break;
                    case 3:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        pergunta = findViewById(R.id.txtPerguntaAtv3);
                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getPergunta(), Toast.LENGTH_SHORT).show();
                        pergunta.setText(perguntaAlterna.getPergunta());

                        break;
                    case 4:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        pergunta = findViewById(R.id.txtPerguntaAtv4);
                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getPergunta(), Toast.LENGTH_SHORT).show();
                        pergunta.setText(perguntaAlterna.getPergunta());

                        break;
                    case 5:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        final NiftyDialogBuilder dialogPDF=NiftyDialogBuilder.getInstance(PaginaDeAtividades.this);
                        final TextView textViewPDF = new TextView(getApplicationContext());
                        textViewPDF.setText(perguntaAlterna.getPergunta());
                        textViewPDF.setTextSize(24);
                        textViewPDF.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                        textViewPDF.setGravity(Gravity.CENTER_HORIZONTAL);
                        textViewPDF.setTextColor(getResources().getColor(R.color.branco));
                        dialogPDF.withTitleColor("#E0F2F1")                                  //def
                                .withDividerColor("#009688")                              //def
                                .withMessageColor("#E0F2F1")                              //def  | withMessageColor(int resid)
                                .withDialogColor("#00BFA5")
                                .setCustomView(textViewPDF, getApplicationContext())
                                .withButton2Text("OK")
                                .isCancelableOnTouchOutside(false)   //def gone//def  | withDialogColor(int resid)
                                .setButton2Click(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                    dialogPDF.dismiss();
                                    }
                                })
                                .withEffect(Effectstype.SlideBottom)
                                .show();
                        break;
                    case 6:
                        perguntaAlterna.setPergunta(dataSnapshot.getValue().toString());
                        pergunta = findViewById(R.id.txtPerguntaAtv6);
                        //Toast.makeText(getApplicationContext(), perguntaAlterna.getPergunta(), Toast.LENGTH_SHORT).show();
                        pergunta.setText(perguntaAlterna.getPergunta());

                        break;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro para pergunta ", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private void parametersFragmentPoints() {
        parametersReference = fireDataAtividades.getReference("Activities").child(Week.codAtividade).child(Week.diaDaSemana).child("pages").child(pagina+String.valueOf(codpageAtual)).child("points");
        parametersReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                perguntaAlterna.setPontos(Integer.valueOf(dataSnapshot.getValue().toString()));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
               //Toast.makeText(getApplicationContext(), "algum erro para points ", Toast.LENGTH_SHORT).show();

            }
        });
    }


}
