package com.cria.agora;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.app.AppCompatDelegate;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import DadosUsuario.UserAchievementes;
import DadosUsuario.UserInfo;

public class Login extends AppCompatActivity {

private Button loginButton;
private EditText editTextMat;
private EditText editTextPassword;
private ProgressBar progressLogin;
private TextView txtVersion;

private DatabaseReference myRef;
private FirebaseDatabase database;

public static UserInfo usuario = null;
public static UserAchievementes userAchievementes = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //tirar action bar
        //getActionBar().hide();

        setContentView(R.layout.activity_login);

        // Inicializar e Instanciar o Firebase
        FirebaseApp.initializeApp(this);
        database = FirebaseDatabase.getInstance();

        // Declarar UI
        loginButton = findViewById(R.id.loginButton);
        editTextMat = findViewById(R.id.editTextmatricula);
        editTextPassword = findViewById(R.id.editTextPass);
        progressLogin = findViewById(R.id.progressBarLogin);
        txtVersion = findViewById(R.id.textVersion);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                   //ação de login
                if (editTextMat.getText().toString().equals("") || editTextPassword.getText().toString().equals("") ){

                    //mensagem caso campos estejam vazios
                    Toast.makeText(getApplicationContext(),"Preencha todos os campos.", Toast.LENGTH_LONG).show();
                }else {
                    // ajustar visibilidade para a barra de progresso
                    loginButton.setVisibility(View.GONE);
                    editTextMat.setVisibility(View.GONE);
                    editTextPassword.setVisibility(View.GONE);
                    txtVersion.setVisibility(View.GONE);
                    progressLogin.setVisibility(View.VISIBLE);

                    //referenciar e Ler do database
                    myRef = database.getReference("users").child(editTextMat.getText().toString()).child("senha");
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            String senha = dataSnapshot.getValue(String.class);
                            if (editTextPassword.getText().toString().equals(senha)) {

                                //popular objeto java com dados do usuário
                                myRef = database.getReference("users").child(editTextMat.getText().toString());
                                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            usuario = new UserInfo();

                                            usuario.setMatricula((String) dataSnapshot.child("matricula").getValue().toString());
                                            usuario.setNome((String) dataSnapshot.child("firstName").getValue().toString());
                                            usuario.setSobrenome((String) dataSnapshot.child("surName").getValue().toString());
                                            usuario.setEmailuser((String) dataSnapshot.child("email").getValue().toString());
                                            usuario.setTele((String) dataSnapshot.child("phone").getValue().toString());
                                            usuario.setEscola((String) dataSnapshot.child("escola").getValue().toString());
                                            usuario.setFunc((String) dataSnapshot.child("func").getValue().toString());
                                            usuario.setDianasci((String) dataSnapshot.child("dia").getValue().toString());
                                            usuario.setMesnasci((String) dataSnapshot.child("mes").getValue().toString());
                                            usuario.setAnonasci((String) dataSnapshot.child("ano").getValue().toString());
                                            usuario.setSexo((String) dataSnapshot.child("sexo").getValue().toString());
                                            usuario.setTipoUser( Long.valueOf(dataSnapshot.child("tipoUser").getValue().toString()));
                                            usuario.setUtbCRIA(Long.valueOf(dataSnapshot.child("utbCRIA").getValue().toString()));


                                        //popular objeto java com achieves de usuário
                                        userAchievementes = new UserAchievementes();
                                        Boolean eco = true;
                                        Boolean forest = true;
                                        Boolean halloween = true;
                                        Boolean number = true;
                                        Boolean labor = true;
                                        Boolean saturn = true;
                                        Boolean summer = true;
                                        Boolean thanksgiving = true;
                                        Boolean travel = true;
                                        Boolean unicorn = true;

                                        if (dataSnapshot.child("achieves").child("badgeEco").getValue()==null){ eco = false; }
                                        if (dataSnapshot.child("achieves").child("badgeForest").getValue()==null){ forest = false; }
                                        if (dataSnapshot.child("achieves").child("badgeHalloween").getValue()==null){ halloween = false; }
                                        if (dataSnapshot.child("achieves").child("badgeLabor").getValue()==null){ labor = false; }
                                        if (dataSnapshot.child("achieves").child("badgeNumber").getValue()==null){ number = false; }
                                        if (dataSnapshot.child("achieves").child("badgeSaturn").getValue()==null){ saturn = false; }
                                        if (dataSnapshot.child("achieves").child("badgeSummer").getValue()==null){ summer = false; }
                                        if (dataSnapshot.child("achieves").child("badgeThanksgiving").getValue()==null){ thanksgiving = false; }
                                        if (dataSnapshot.child("achieves").child("badgeTravel").getValue()==null){ travel = false; }
                                        if (dataSnapshot.child("achieves").child("badgeUnicorn").getValue()==null){ unicorn = false; }

                                        userAchievementes.setBadgeEco(eco);
                                        userAchievementes.setBadgeForest(forest);
                                        userAchievementes.setBadgeHalloween(halloween);
                                        userAchievementes.setBadgeLaborDay(labor);
                                        userAchievementes.setBadgeNumberOne(number);
                                        userAchievementes.setBadgeSaturn(saturn);
                                        userAchievementes.setBadgeSummer(summer);
                                        userAchievementes.setBadgeThanksgiving(thanksgiving);
                                        userAchievementes.setBadgeTravel(travel);
                                        userAchievementes.setBadgeUnicorn(unicorn);
                                        //ir para nova activity

                                        if (usuario.getTipoUser()==0){

                                            Intent intent = new Intent(getApplicationContext(), MainAdm.class);
                                            startActivity(intent);

                                            finish();
                                            //Toast.makeText(getApplicationContext(), String.valueOf(itipoUser), Toast.LENGTH_SHORT).show();
                                        }else {

                                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                            startActivity(intent);
                                            finish();
                                            //Toast.makeText(getApplicationContext(), String.valueOf(itipoUser), Toast.LENGTH_SHORT).show();
                                        }



                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });







                            } else {
                                Toast.makeText(getApplicationContext(),"Matrícula ou senha incorreta.", Toast.LENGTH_LONG).show();
                                loginButton.setVisibility(View.VISIBLE);
                                editTextMat.setVisibility(View.VISIBLE);
                                editTextPassword.setVisibility(View.VISIBLE);
                                progressLogin.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(),"Usuário não encontrado", Toast.LENGTH_LONG).show();
                            loginButton.setVisibility(View.VISIBLE);
                            editTextMat.setVisibility(View.VISIBLE);
                            editTextPassword.setVisibility(View.VISIBLE);
                            progressLogin.setVisibility(View.GONE);

                        }
                    });

                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //teste e ajeitar visual após login
        //Toast.makeText(getApplicationContext(),"Sucesso", Toast.LENGTH_LONG).show();
        loginButton.setVisibility(View.VISIBLE);
        editTextMat.setVisibility(View.VISIBLE);
        editTextPassword.setVisibility(View.VISIBLE);
        progressLogin.setVisibility(View.GONE);
    }
}

/*
     // Write a message to the database
       FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("message").child("azul");
                myRef.setValue("Hello, World!");

                // Read from the database
                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        // This method is called once with the initial value and again
                        // whenever data at this location is updated.
                        String value = dataSnapshot.getValue(String.class);
                        Log.d("sucesso", "Value is: " + value);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        // Failed to read value
                        Log.w("falha", "Failed to read value.", databaseError.toException());
                    }
                });


                  usuario = new UserInfo(database.getReference("users").child(editTextMat.getText().toString()).child("matricula").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("firstName").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("surName").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("email").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("phone").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("escola").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("func").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("dia").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("mes").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("ano").toString(),
                                        database.getReference("users").child(editTextMat.getText().toString()).child("sexo").toString());

                                            usuario = new UserInfo((String) dataSnapshot.child("matricula").getValue(),
                                                (String) dataSnapshot.child("firstName").getValue(),
                                                (String) dataSnapshot.child("surName").getValue(),
                                                (String) dataSnapshot.child("email").getValue(),
                                                (String) dataSnapshot.child("phone").getValue(),
                                                (String) dataSnapshot.child("escola").getValue(),
                                                (String) dataSnapshot.child("func").getValue(),
                                                (String) dataSnapshot.child("dia").getValue(),
                                                (String) dataSnapshot.child("mes").getValue(),
                                                (String) dataSnapshot.child("ano").getValue(),
                                                (String) dataSnapshot.child("sexo").getValue());
 */