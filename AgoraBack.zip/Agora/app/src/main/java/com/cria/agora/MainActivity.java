package com.cria.agora;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import DadosUsuario.UserPerformance;

public class MainActivity extends AppCompatActivity {

    private TextView seuNomeTitle;
    private TextView atividades;
    private TextView score;
    private TextView nivel;
    private TextView firstName;
    private TextView surname;
    private TextView escola;
    private TextView email;
    private TextView telefone;

    public static UserPerformance performance;



    private ImageButton avatar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //declarar elementos
        seuNomeTitle = findViewById(R.id.textName);
        atividades = findViewById(R.id.txt_atividades);
        score = findViewById(R.id.txt_score);
        nivel = findViewById(R.id.txt_nivel);
        firstName = findViewById(R.id.txt_firstName);
        surname = findViewById(R.id.txt_surname);
        escola = findViewById(R.id.txt_school);
        email = findViewById(R.id.txt_email);
        telefone = findViewById(R.id.txt_number);
        avatar = findViewById(R.id.img_avatar);


        //popular os txt com infos do usuário que fez login através do objeto usuario da classe UserInfo
        seuNomeTitle.setText(Login.usuario.getNome());
        firstName.setText(Login.usuario.getNome());
        surname.setText(Login.usuario.getSobrenome());
        escola.setText(Login.usuario.getEscola());
        email.setText(Login.usuario.getEmailuser());
        telefone.setText(Login.usuario.getTele());







        ImageButton fab = (ImageButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Atividades.class);
                Atividades.isPerformance=false;
                startActivity(intent);
            }
        });
        ImageButton badge = (ImageButton) findViewById(R.id.btn_badge);
        badge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Achivements.class);
                startActivity(intent);

            }
        });
        ImageButton sair = (ImageButton) findViewById(R.id.btn_sair);
        sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);

            }
        });
        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AvatarChoice.class);
                startActivity(intent);
            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();

        //popular a performance
        String refUser = Login.usuario.getMatricula();
        FirebaseDatabase fireUser = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReferenceUser = fireUser.getReference("users").child(refUser).child("desempenho");
        databaseReferenceUser.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                long iAtv = (long)dataSnapshot.child("atvRealizadas").getValue();
                long iScore = (long) dataSnapshot.child("score").getValue();
                long iAvatar = (long) dataSnapshot.child("avatar").getValue();
                String iLevel = (String) dataSnapshot.child("level").getValue();

                //Toast.makeText(getApplicationContext(), String.valueOf(iScore), Toast.LENGTH_LONG).show();

                performance = new UserPerformance(iAtv, iScore, iLevel, iAvatar);

                atividades.setText(String.valueOf(performance.getAtividades()));
                score.setText(String.valueOf(performance.getPontos()));
                nivel.setText(performance.getLevel());


                int iAvatar2 = (int) performance.getAvatar();
                switch (iAvatar2){
                    case 1: avatar.setImageResource(R.drawable.animal1); break;
                    case 2: avatar.setImageResource(R.drawable.animal2); break;
                    case 3: avatar.setImageResource(R.drawable.animal3); break;
                    case 4: avatar.setImageResource(R.drawable.animal4); break;
                    case 5: avatar.setImageResource(R.drawable.animal5); break;
                    case 6: avatar.setImageResource(R.drawable.animal6); break;
                    case 7: avatar.setImageResource(R.drawable.animal7); break;
                    case 8: avatar.setImageResource(R.drawable.animal8); break;
                    case 9: avatar.setImageResource(R.drawable.animal9); break;
                    case 11: avatar.setImageResource(R.drawable.fruit1); break;
                    case 12: avatar.setImageResource(R.drawable.fruit2); break;
                    case 13: avatar.setImageResource(R.drawable.fruit3); break;
                    case 14: avatar.setImageResource(R.drawable.fruit4); break;
                    case 15: avatar.setImageResource(R.drawable.fruit5); break;
                    case 16: avatar.setImageResource(R.drawable.fruit6); break;
                    case 17: avatar.setImageResource(R.drawable.fruit7); break;
                    case 18: avatar.setImageResource(R.drawable.fruit8); break;
                    case 19: avatar.setImageResource(R.drawable.fruit9); break;
                    case 21: avatar.setImageResource(R.drawable.food1); break;
                    case 22: avatar.setImageResource(R.drawable.food2); break;
                    case 23: avatar.setImageResource(R.drawable.food3); break;
                    case 24: avatar.setImageResource(R.drawable.food4); break;
                    case 25: avatar.setImageResource(R.drawable.food5); break;
                    case 26: avatar.setImageResource(R.drawable.food6); break;
                    case 27: avatar.setImageResource(R.drawable.food7); break;
                    case 28: avatar.setImageResource(R.drawable.food8); break;
                    case 29: avatar.setImageResource(R.drawable.food9); break;
                    case 31: avatar.setImageResource(R.drawable.sky1); break;
                    case 32: avatar.setImageResource(R.drawable.sky2); break;
                    case 33: avatar.setImageResource(R.drawable.sky3); break;
                    case 34: avatar.setImageResource(R.drawable.sky4); break;
                    case 35: avatar.setImageResource(R.drawable.sky5); break;
                    case 36: avatar.setImageResource(R.drawable.sky6); break;
                    case 37: avatar.setImageResource(R.drawable.sky7); break;
                    case 38: avatar.setImageResource(R.drawable.sky8); break;
                    case 39: avatar.setImageResource(R.drawable.sky9); break;
                    case 41: avatar.setImageResource(R.drawable.dessert1); break;
                    case 42: avatar.setImageResource(R.drawable.dessert2); break;
                    case 43: avatar.setImageResource(R.drawable.dessert3); break;
                    case 44: avatar.setImageResource(R.drawable.dessert4); break;
                    case 45: avatar.setImageResource(R.drawable.dessert5); break;
                    case 46: avatar.setImageResource(R.drawable.dessert6); break;
                    case 47: avatar.setImageResource(R.drawable.dessert7); break;
                    case 48: avatar.setImageResource(R.drawable.dessert8); break;
                    case 49: avatar.setImageResource(R.drawable.dessert9); break;
                    case 51: avatar.setImageResource(R.drawable.sushi1); break;
                    case 52: avatar.setImageResource(R.drawable.sushi2); break;
                    case 53: avatar.setImageResource(R.drawable.sushi3); break;
                    case 54: avatar.setImageResource(R.drawable.sushi4); break;
                    case 55: avatar.setImageResource(R.drawable.sushi5); break;
                    case 56: avatar.setImageResource(R.drawable.sushi6); break;
                    case 57: avatar.setImageResource(R.drawable.sushi7); break;
                    case 58: avatar.setImageResource(R.drawable.sushi8); break;
                    case 59: avatar.setImageResource(R.drawable.sushi9); break;
                    case 61: avatar.setImageResource(R.drawable.character1); break;
                    case 62: avatar.setImageResource(R.drawable.character2); break;
                    case 63: avatar.setImageResource(R.drawable.character3); break;
                    case 64: avatar.setImageResource(R.drawable.character4); break;
                    case 65: avatar.setImageResource(R.drawable.character5); break;
                    case 66: avatar.setImageResource(R.drawable.character6); break;
                    case 67: avatar.setImageResource(R.drawable.character7); break;
                    case 68: avatar.setImageResource(R.drawable.character8); break;
                    case 69: avatar.setImageResource(R.drawable.character9); break;
                    case 71: avatar.setImageResource(R.drawable.plant1); break;
                    case 72: avatar.setImageResource(R.drawable.plant2); break;
                    case 73: avatar.setImageResource(R.drawable.plant3); break;
                    case 74: avatar.setImageResource(R.drawable.plant4); break;
                    case 75: avatar.setImageResource(R.drawable.plant5); break;
                    case 76: avatar.setImageResource(R.drawable.plant6); break;
                    case 77: avatar.setImageResource(R.drawable.plant7); break;
                    case 78: avatar.setImageResource(R.drawable.plant8); break;
                    case 79: avatar.setImageResource(R.drawable.plant9); break;
                    case 81: avatar.setImageResource(R.drawable.vegetable1); break;
                    case 82: avatar.setImageResource(R.drawable.vegetable2); break;
                    case 83: avatar.setImageResource(R.drawable.vegetable3); break;
                    case 84: avatar.setImageResource(R.drawable.vegetable4); break;
                    case 85: avatar.setImageResource(R.drawable.vegetable5); break;
                    case 86: avatar.setImageResource(R.drawable.vegetable6); break;
                    case 87: avatar.setImageResource(R.drawable.vegetable7); break;
                    case 88: avatar.setImageResource(R.drawable.vegetable8); break;
                    case 89: avatar.setImageResource(R.drawable.vegetable9); break;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }









}
