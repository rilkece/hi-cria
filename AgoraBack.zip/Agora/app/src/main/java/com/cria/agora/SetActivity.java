package com.cria.agora;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.sdsmdg.tastytoast.TastyToast;

import TiposdeAtividades.PerguntaAlterna;

public class SetActivity extends AppCompatActivity {

    private TextView confgText;

    public static int ipaginaAtividade;







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);

        //inicializar elementos
        confgText = findViewById(R.id.txtSetActivity);
        if (ipaginaAtividade==999){
            confgText.setText("Edite a atividade.");
        }else {
            confgText.setText("Configure a tela da atividade "+String.valueOf(ipaginaAtividade)+".");
        }




        settingTheSetting();

    }



    private void settingTheSetting() {
        super.onStop();

        switch (EscolhaTipoAtividade.iAtividadeAtual) {
            case 1:
               // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv1())
                        .commitNowAllowingStateLoss();
                break;
            case 2:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv2())
                        .commitNowAllowingStateLoss();
                break;
            case 3:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv3())
                        .commitNowAllowingStateLoss();
                break;
            case 4:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv4())
                        .commitNowAllowingStateLoss();
                break;
            case 5:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv5())
                        .commitNowAllowingStateLoss();
                break;
            case 6:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv6())
                        .commitNowAllowingStateLoss();
                break;
            case 7:
                // Toast.makeText(getApplicationContext(), "setting the set2", TastyToast.LENGTH_SHORT).show();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.frameConfigAtv, new SetAtv7())
                        .commitNowAllowingStateLoss();
                break;

        }
    }

}
