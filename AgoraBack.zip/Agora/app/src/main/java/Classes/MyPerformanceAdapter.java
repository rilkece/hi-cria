package Classes;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.annotation.GlideModule;
import com.cria.agora.Atividades;
import com.cria.agora.Login;
import com.cria.agora.Performance;
import com.cria.agora.R;
import com.cria.agora.Week;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.sdsmdg.tastytoast.TastyToast;
import com.suke.widget.SwitchButton;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;

import DadosUsuario.UserWeekPerformance;

public class MyPerformanceAdapter extends RecyclerView.Adapter<MyPerformanceAdapter.MyViewHolder> {

    Context context;
    ArrayList<UserWeekPerformance> perfilWeekScore;

    public MyPerformanceAdapter(Context c, ArrayList<UserWeekPerformance> p){
        context = c;
        perfilWeekScore = p;

    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.cardview_performance, viewGroup, false));

    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        String Name = perfilWeekScore.get(i).getName()+" "+perfilWeekScore.get(i).getSurname();
        String schoolName = perfilWeekScore.get(i).getSchool();
        String pontuacao = String.valueOf(perfilWeekScore.get(i).getWeekScore());

        myViewHolder.pontos.setText(pontuacao);
        myViewHolder.nome.setText(Name);
        myViewHolder.escola.setText(schoolName);
        if (i==0){
            myViewHolder.cardPerformance.setCardBackgroundColor(context.getResources().getColor(R.color.Progress2));
        }

    }

    @Override
    public int getItemCount() {
        return perfilWeekScore.size();
    }

    class  MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView nome;
        TextView escola;
        TextView pontos;
        CardView cardPerformance;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nome = (TextView) itemView.findViewById(R.id.txtPerfName);
            escola = (TextView) itemView.findViewById(R.id.txtPerfSchool);
            pontos = (TextView) itemView.findViewById(R.id.txtPerfScore);
            cardPerformance= (CardView) itemView.findViewById(R.id.cardPerformance);


        }
        }



}
